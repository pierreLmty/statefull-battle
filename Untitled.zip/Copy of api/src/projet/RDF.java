package projet;

public class RDF {
	
	//methode generant les question via appel rdf
	public void genererQuestions(){
		
	}
}
