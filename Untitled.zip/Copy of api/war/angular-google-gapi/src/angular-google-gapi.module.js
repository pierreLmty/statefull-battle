/**
 * An AngularJS module for use all Google Apis and your Google Cloud Endpoints
 * @version 1.0.0-beta.2
 * @link https://github.com/maximepvrt/angular-google-gapi
 */

(function() {
    'use strict';
    angular.module('angular-google-gapi', []);
})();