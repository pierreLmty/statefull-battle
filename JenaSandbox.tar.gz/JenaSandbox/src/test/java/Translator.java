/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.sparql.vocabulary.FOAF;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author E125078E
 */
public class Translator {
    
    public Model personneToFOAF(Personne p, String uri)
    {
        Model model = ModelFactory.createDefaultModel();
        model.createResource(uri)
                .addProperty(FOAF.name, p.getNom() + " " + p.getPrenom())
                .addProperty(FOAF.nick, p.getNom() + " " + p.getPrenom())
                .addProperty(FOAF.birthday, ""+p.getAge());

        return model;
    }
    
    public Personne foafToPersonne(Model m,String uri)
    {
        Resource r = m.getResource(uri);
        Personne p = new Personne();
        
        ;
        return p;
    }
    
    //obtenir des uri random, UUID.randomUID();
}
