/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




/**
 *
 * @author E125078E
 */
public class Personne {
    private String nom;
    private String prenom;
    private int age;
    
    Personne(String n, String p, int a)
    {
        this.nom=n;
        this.prenom=p;
        this.age=a;
    }
    
    Personne(){}
    
    //getter_setter
    
    public String getNom() {return nom;}
    public String getPrenom(){return prenom;}
    public int getAge(){return age;}
    
    public void setNom(String n){this.nom =n;}
    public void setPrenom(String n){this.prenom =n;}
    public void setAge(int n){this.age =n;}
    
}
