/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;
import org.apache.jena.query.Dataset;
import org.apache.jena.query.DatasetFactory;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.update.UpdateAction;
import org.apache.jena.util.FileManager;

/**
 *
 * @author E125078E
 */


public class TD2 
{

    private static Model model = ModelFactory.createDefaultModel();
    private static Dataset dataset = DatasetFactory.create();
    private static Scanner input;

    public static void main(String[] args) 
    {
	input = new Scanner(System.in);
	System.out.println("Quelle Exercice de TD2?");
	int nbQ = input.nextInt();

	switch (nbQ) 
        {
	case 1: doEx1();
	 break;
	case 2: doEx2();
	 break;
	case 3: doEx3();
	 break;
	case 6: doEx6();
	 break;
        case 7: doTestWC();
         break;
	}	
    }
    
    public static void doEx1()
    {
        input = new Scanner(System.in);
        System.out.println("Working Directory = " + System.getProperty("user.dir"));
        readingRDF("/comptes/E125078E/Documents/M1/S1/WebSemantique/TP2/dataset.rdf");
        System.out.println("Query number for Ex1");
        int nbQ = input.nextInt();
	switch (nbQ) 
        {
            case 1: 
             doRequest("/comptes/E125078E/Documents/M1/S1/WebSemantique/TP2/qr11.rq");
             break;
            case 2:
             doRequest("/comptes/E125078E/Documents/M1/S1/WebSemantique/TP2/qr12.rq");
             break;
            case 3 :
             doUpdate("/comptes/E125078E/Documents/M1/S1/WebSemantique/TP2/qr13.rq");
             doRequest("/comptes/E125078E/Documents/M1/S1/WebSemantique/TP2/qr12.rq");
             break;
            case 4:
             doUpdate("/comptes/E125078E/Documents/M1/S1/WebSemantique/TP2/qr13.rq");
             doRequest("/comptes/E125078E/Documents/M1/S1/WebSemantique/TP2/qr14.rq");
             break;
            case 5:
             doRequest("/comptes/E125078E/Documents/M1/S1/WebSemantique/TP2/qr15.rq");
             break;
	}
    }
    public static void doEx2()
    {
        // /comptes/E125078E/Documents/M1/S1/WebSemantique/TP2
    }
    public static void doEx3() 
    {

    input = new Scanner(System.in);
    System.out.println("Working Directory = " + System.getProperty("user.dir"));
    readingRDF("dataX3.rdf");
    System.out.println("Query number for Ex3");
    int nbQ = input.nextInt();
	switch (nbQ) 
        {
	case 1: 
	 doRequest("question31.rq");
	 break;
	case 2: 
         doRequest("question32.rq");
	 break;
	case 3 :
         doRequest("question33.rq");
	break;
	}	
    }
    public static void doEx6()
    {
        
    }

    public static void readingRDF(String filename)
    {
    // Open RDF file
    InputStream in = FileManager.get().open(filename);
    if (in == null) 
    {
        throw new IllegalArgumentException("File not found");
    }
    // Load file content
    model.read(in, null, "TTL");
    dataset.addNamedModel("http://example.org/", model);
    //model.write(System.out, "Turtle");
    }
    
    public static void doTestWC()
    {
        //comptes/E125078E/Documents/M1/S1/Web&Cloud/projet
        input = new Scanner(System.in);
        System.out.println("Working Directory = " + System.getProperty("user.dir"));
        dataset.addNamedModel("http://example.org/", model);
        System.out.println("Query number for Ex3");
        doRequest("/comptes/E125078E/Documents/M1/S1/Web&Cloud/projet/requet.rq");
    }

    public static String readQuery(String filename)
    {
        try 
        {
	    File file = new File(filename);
	    FileInputStream inputStream = new FileInputStream(file);
	    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
	    StringBuilder data = new StringBuilder();
	    String line;
            while ((line = reader.readLine()) != null) 
            {
                data.append(line + "\n");
            }

            inputStream.close();
            return data.toString();
	}
	catch(Exception ex)
        {
            return null;
	}
    }

    public static void doRequest(String filename)
    {

	String request = readQuery(filename);

	System.out.println("\n-> Request on file: \"" + filename + "\"");
	System.out.println(request);
	System.out.println("-> Perform request...\n");

	Query query = QueryFactory.create(request);
	QueryExecution qexec = QueryExecutionFactory.sparqlService("http://dbpedia.org/sparql",query);
                //create(query, dataset.getNamedModel("http://example.org/"));
	ResultSet results =  qexec.execSelect();

	// Output query results	
	ResultSetFormatter.out(System.out, results, query);

	// Important - free up resources used running the query
	qexec.close();
    }
    
    public static void doUpdate(String filename)
    {
        UpdateAction.readExecute(filename, dataset.getNamedModel("http://example.org/")) ;
    }
    
    //NamedGraph , Dataset, updateRequest

}